import './App.css';
import Home from "./component/UI/Home";


function App() {

    return (
    <div>
        <Home/>
    </div>
  );
}

export default App;
