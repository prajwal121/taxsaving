import classes from "./Button.module.css";


function Button(props){
    return(
        <div>
            <button type="submit" className={classes.button} id="nextBtn" onClick={props.onClick}>{props.children}
             </button>
        </div>
    )
}
export default Button