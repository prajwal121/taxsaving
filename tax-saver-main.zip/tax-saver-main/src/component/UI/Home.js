import React, {useState} from "react";
import './Home.module.css'
import UsersDetails from "../users/UsersDeatils";


function Home(props) {

    const [showComponent, setShowComponent] = useState(false);
    const [showForm, setShowForm] = useState(true);

    const handleSubmit = async event => {
        event.preventDefault();
        setShowComponent(true);
        setShowForm(!showForm)

    }

    return (
        <div>
            {showForm && (
            <div className="container-fluid l_page">
                <div className="row d-flex">
                    <div className="col-md-1"></div>
                    <div className="col-md-7 mt-5">
                        <img src="https://img.freepik.com/free-vector/calculator-concept-illustration_114360-1239.jpg"
                             alt="description of image"
                             style={{backgroundRepeat: "no-repeat", backgroundPosition: 'top'}}
                        />
                    </div>
                    <div className="col-md-4 mt-5 mb-5">
                        <h1 className="title" style={{paddingTop: 125}}>Save and Personalize Your Tax Here</h1>

                            <div className='title-button'style={{paddingTop: 50}}>
                                <button className="btn btn-success mt-5"  type='submit' style={{padding: 15, borderRadius: 12}} onClick={handleSubmit}>Personalize Tax</button>
                            </div>

                    </div>
                </div>
            </div>
            )}
            {showComponent && (
                <div className="container-fluid align-middle">
                    <UsersDetails/>
                </div>
            )}
        </div>
    )
}

export default Home