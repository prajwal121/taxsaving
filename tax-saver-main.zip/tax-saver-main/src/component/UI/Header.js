import "./Header.css"

function Header() {
    return (
        <div>
            <div className="container-fluid navbar mb-5">
                <div className="row">
                    <div className="d-flex justify-content-center">
                        <h3>Tax Optimizer</h3>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Header