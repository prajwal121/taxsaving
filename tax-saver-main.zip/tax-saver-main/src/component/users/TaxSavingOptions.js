import React, {useState} from "react";
import axios from 'axios'
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 800,
    bgcolor: 'background.paper',
    border: '2px solid #3cb043',
    borderRadius: '10px',
    boxShadow: 24,
    p: 4,
};


function TaxSavingOptions (props) {
    let [retirementAccountSavings, setRetirementAccountSavings] = useState(0);
    let [taxDeductionsSavings, setTaxDeductionsSavings] = useState(0);
    let [taxExemptInvestmentSavings, setTaxExemptInvestmentSavings] = useState(0);
    let [eightyCDeduction, setEightyCDeduction] = useState(0);
    let [homeLoanDeduction, setHomeLoanDeduction] = useState(0)
    let [medicalDeductionAmount, setMedicalDeductionAmount] = useState(0)
    let [deduction80GG, setDeduction80GG] = useState(0)
    const [showComponent, setShowComponent] = useState(false)
    //retirement
    const [openRetirement, setOpenRetirement] = useState(false);
    const handleOpen = () => setOpenRetirement(true);
    const handleClose = () => setOpenRetirement(false);

    //retirement
    const [openTaxDeduction, setOpenTaxDeduction] = useState(false);
    const handleOpenTaxDeduction = () => setOpenTaxDeduction(true);
    const handleCloseTaxDeduction = () => setOpenTaxDeduction(false);

    //retirement
    const [openExemptInvestment, setOpenExemptInvestment] = useState(false);
    const handleOpenExemptInvestment = () => setOpenExemptInvestment(true);
    const handleCloseExemptInvestment = () => setOpenExemptInvestment(false);

    //retirement
    const [openCDeduction, setOpenCDeduction] = useState(false);
    const handleOpenCDeduction = () => setOpenCDeduction(true);
    const handleCloseCDeduction = () => setOpenCDeduction(false);

    //retirement
    const [openLoanDeduction, setOpenLoanDeduction] = useState(false);
    const handleOpenLoanDeduction = () => setOpenLoanDeduction(true);
    const handleCloseLoanDeduction = () => setOpenLoanDeduction(false);

    //retirement
    const [openDeductionAmount, setOpenDeductionAmount] = useState(false);
    const handleOpenDeductionAmount = () => setOpenDeductionAmount(true);
    const handleCloseDeductionAmount = () => setOpenDeductionAmount(false);

    //retirement
    const [open80GG, setOpen80GG] = useState(false);
    const handleOpen80GG = () => setOpen80GG(true);
    const handleClose80GG = () => setOpen80GG(false);

    const taxLiabilityAmount = parseFloat(props.totalTaxtAmount)
    const savedIncome = props.savedIncome
    let investmentAmount = 150000;
    let interestRate = 8;
    let duration = 5;

    const loanAmount = 1000000;
    const homeInterestRate = 8;
    const tenure = 20;

    // Calculate total interest paid on loan
    const totalInterestPaid = (loanAmount * homeInterestRate * tenure) / 100;

    // Deduct the amount eligible for Section 80EE, which is up to Rs. 50,000
    const section80EEDeduction = Math.min(totalInterestPaid, 50000);

    //  80DDB calculation
    let personAge = props.age
    let dependentAge = props.dependentAge
    let medicalExpense = props.medicalInvestments

    // Deduction calculation
    if (personAge < 60) {
        if (dependentAge < 60) {
            if (medicalExpense <= 40000) {
                medicalDeductionAmount = medicalExpense;
            } else {
                medicalDeductionAmount = 40000;
            }
        } else {
            if (medicalExpense <= 100000) {
                medicalDeductionAmount = medicalExpense;
            } else {
                medicalDeductionAmount = 100000;
            }
        }
    } else {
        if (dependentAge < 60) {
            if (medicalExpense <= 60000) {
                medicalDeductionAmount = medicalExpense;
            } else {
                medicalDeductionAmount = 60000;
            }
        } else {
            if (medicalExpense <= 120000) {
                medicalDeductionAmount = medicalExpense;
            } else {
                medicalDeductionAmount = 120000;
            }
        }
    }

    let rentExemption = 0;
    let rentPaid = 3000

    // Calculate rent exemption as per the rules
    rentExemption = Math.min(5000, rentPaid);
    rentExemption = Math.min(rentExemption, taxLiabilityAmount * 0.1);
    rentExemption = Math.min(rentExemption, taxLiabilityAmount * 0.25);

    // Calculate the deduction under section 80GG
    deduction80GG = rentExemption;
    const handleSubmit = async (e) => {
        e.preventDefault();

        // Calculate tax savings using various strategies
        const RetirementSavings = Number((taxLiabilityAmount * 0.3).toFixed(2)); // 30% of tax liability amount
        const DeductionsSavings = Number((taxLiabilityAmount * 0.2.toFixed(2))); // 20% of tax liability amount
        const InvestmentSavings = Number((taxLiabilityAmount * 0.1).toFixed(2)); // 10% of tax liability amount
        const EightyCDeduction = Number((investmentAmount * Math.pow(1 + (interestRate / 100), duration)).toFixed(2));
// Calculate the taxable income after deducting Section 80EE deduction
        const afterHomeLoadDeduction = taxLiabilityAmount - section80EEDeduction;

        setEightyCDeduction(EightyCDeduction)
        setRetirementAccountSavings(RetirementSavings)
        setTaxDeductionsSavings(DeductionsSavings)
        setTaxExemptInvestmentSavings(InvestmentSavings)
        setHomeLoanDeduction(afterHomeLoadDeduction)
        setMedicalDeductionAmount(medicalDeductionAmount)
        setDeduction80GG(deduction80GG)

        await saveSavingOptions(
            RetirementSavings,
            DeductionsSavings,
            InvestmentSavings,
            EightyCDeduction
            )

        // Displaying component
        setShowComponent(true);
    };

    const saveSavingOptions = async (
        RetirementSavings,
        DeductionsSavings,
        InvestmentSavings,
        EightyCDeduction
    ) => {
        axios.post(`${process.env.REACT_APP_API_ENDPOINT}/saving_options/add`,
            {
                income_id: savedIncome._id,
                RetirementSavings,
                DeductionsSavings,
                InvestmentSavings,
                EightyCDeduction
            })
            .then(res => {
                console.log(res.data)
            })
            .catch(err => {
                console.log(err)
            })
    }


    return(
        <div>
            <div className='row col-md-3 mb-3'>
                {!showComponent && (
                    <div className="d-flex justify-content-center">
                        <Button variant="contained" color="success" endIcon={<ReceiptLongIcon />} onClick={handleSubmit}> Show Tax Saving Options</Button>
                    </div>
                )}
            </div>
            {showComponent && (
                <div className="container-fluid">
                    <div className="row d-flex me-2">

                        <div className="card" style={{width: 18 + 'rem', marginRight: 5}}>
                            <img className="card-img-top" src="https://img.freepik.com/free-vector/retirement-concept-illustration_114360-16028.jpg" alt="Card image cap"/>
                            <div className="card-body">
                                <h5 className="card-title"><strong> &#8377; {retirementAccountSavings}</strong></h5>
                                <p className="card-text">By contributing to retirement accounts:{" "}</p>
                            </div>
                            <div className="card-footer">
                                    <div>
                                        <button className="btn btn-success mt-5" style={{padding: 15, borderRadius: 12}} onClick={handleOpen}>Explore</button>
                                            <Modal
                                                open={openRetirement}
                                                onClose={handleClose}
                                                aria-labelledby="modal-modal-title"
                                                aria-describedby="modal-modal-description"
                                            >
                                                <Box sx={style}>
                                                    <Typography id="modal-modal-title" variant="h6" component="h2">
                                                        <h4 className="card-title"><strong> Exemption for senior citizens from filing income tax returns per Section 194P of the Income Tax Act, 1961</strong></h4>
                                                    </Typography>
                                                    <Typography id="modal-modal-description" sx={{mt: 2}}>
                                                        <h6 className="card-title mb-2"><strong> Requirements:</strong></h6>
                                                        <p className="card-text">Age 75+</p>
                                                        <p className="card-text">Resident in the previous yea</p>
                                                        <p className="card-text">Only pension and interest income from the designated bank. Effective 1 April 2021.</p>
                                                        <h6 className="card-title mb-2"><strong>For Senior Citizens Tax Slab (60-80 years of age):</strong></h6>
                                                        <p className="card-text">Upto INR 3 lakhs- no tax.</p>
                                                        <p className="card-text">INR 3 lakh- INR 5 lakh- 5% on income above INR 3 lakh + 4% cess on income tax.</p>
                                                        <p className="card-text">More than INR 10 lakh- INR 1,10,000 + 30% tax on income above INR 10 lakh +4% cess on income tax.</p>
                                                        <h6 className="card-title mb-2"><strong>For Senior Citizens Tax Slab (above 80 years of age):</strong></h6>
                                                        <p className="card-text">Upto INR 5 lakh- no tax</p>
                                                        <p className="card-text">INR 5 lakh- INR 10 lakh- 20% tax on income above INR 5 lakh + 4% cess on income tax.</p>
                                                        <p className="card-text">More than INR 10 lakh- INR 1,00,000 + 30% tax on income above INR 10 lakh +4% cess on income tax.</p>
                                                    </Typography>
                                                </Box>
                                            </Modal>
                                    </div>
                            </div>
                        </div>

                         <div className="card" style={{width: 18 + 'rem', marginRight: 5}}>
                             <img className="card-img-top" src="https://img.freepik.com/free-vector/international-non-resident-taxes-abstract-concept-illustration_335657-5188.jpg?w=2000" alt="Card image cap"/>
                            <div className="card-body">
                                <h5 className="card-title"><strong> &#8377; {taxDeductionsSavings}</strong></h5>
                                <p className="card-text"> By claiming tax deductions:{" "}</p>
                            </div>
                             <div className="card-footer">
                                 <div>
                                     <button className="btn btn-success mt-5" style={{padding: 15, borderRadius: 12}} onClick={handleOpenTaxDeduction}>Explore</button>
                                     <Modal
                                         open={openTaxDeduction}
                                         onClose={handleCloseTaxDeduction}
                                         aria-labelledby="modal-modal-title"
                                         aria-describedby="modal-modal-description"
                                     >
                                         <Box sx={style}>
                                             <Typography id="modal-modal-title" variant="h6" component="h2">
                                                 Income Tax on Salary
                                             </Typography>
                                             <Typography id="modal-modal-description" sx={{mt: 2}}>
                                                 <table className="table">
                                                     <thead className="thead-dark">
                                                     <tr>
                                                         <th scope="col">Net income range</th>
                                                         <th scope="col">Income-Tax rate</th>
                                                         <th scope="col">Your tax outgo before Rebate under Section 87A</th>
                                                     </tr>
                                                     </thead>
                                                     <tbody>
                                                     <tr>
                                                         <td>Up to ₹ 2,50,000	</td>
                                                         <td>Nil</td>
                                                         <td>Nil</td>
                                                     </tr>
                                                     <tr>
                                                         <td>₹ 2,50,000 – ₹ 5,00,000</td>
                                                         <td>5%</td>
                                                         <td>₹ 12,500</td>
                                                     </tr>
                                                     <tr>
                                                         <td>₹ 5,00,000 – ₹ 10,00,000</td>
                                                         <td>20%</td>
                                                         <td>₹ 1 lakh</td>
                                                     </tr>
                                                     <tr>
                                                         <td>Above ₹ 10,00,000</td>
                                                         <td>30%</td>
                                                         <td>₹ 2,62,500 assuming net income of ₹ 15 lakh</td>
                                                     </tr>
                                                     </tbody>
                                                 </table>
                                             </Typography>
                                         </Box>
                                     </Modal>
                                 </div>
                             </div>
                         </div>

                        <div className="card" style={{width: 18 + 'rem', marginRight: 5}}>
                            <img className="card-img-top" src="https://img.freepik.com/free-vector/investing-concept-illustration_114360-3555.jpg?w=2000" alt="Card image cap"/>
                            <div className="card-body">
                                <h5 className="card-title"> <strong> &#8377; {taxExemptInvestmentSavings}</strong></h5>
                                <p className="card-text">By investing in tax-exempt securities:{" "}</p>
                            </div>
                            <div className="card-footer">
                                <div>
                                    <button className="btn btn-success mt-5" style={{padding: 15, borderRadius: 12}} onClick={handleOpenExemptInvestment}>Explore</button>
                                    <Modal
                                        open={openExemptInvestment}
                                        onClose={handleCloseExemptInvestment}
                                        aria-labelledby="modal-modal-title"
                                        aria-describedby="modal-modal-description"
                                    >
                                        <Box sx={style}>
                                            <Typography id="modal-modal-title" variant="h6" component="h2">
                                                Tax Investment
                                            </Typography>
                                            <Typography id="modal-modal-description" sx={{mt: 2}}>
                                                The tax saving calculator helps you to calculate tax-savings, after making use of Section 80C of the Income Tax Act, 1961.

                                                Let us understand how to calculate tax savings using Section 80C. For example, your gross taxable income is Rs 9,00,000 per annum. You have the standard deduction of Rs 50,000 per year. You will then have to deduct the eligible expenses and investments under Section 80C.

                                                Suppose you have invested Rs 1.5 lakh in an ELSS fund. The taxable income reduces to Rs 9,00,000 – Rs 50,000 – Rs 1,50,000 = Rs 7,00,000.

                                                You then calculate the taxes depending on your income tax bracket. Suppose you are under 60 years of age, you fall in the income tax slab for individual payers who are below 60 years. You would incur an income tax liability of Rs 52,000. (Do note the calculations do not consider the 4% cess)

                                                However, if you had not utilised the Section 80C deduction, you would have incurred a tax liability of Rs 92,500. You have saved Rs 40,500 by using the Section 80C tax deduction.
                                            </Typography>
                                        </Box>
                                    </Modal>
                                </div>
                            </div>
                        </div>

                        <div className="card" style={{width: 18 + 'rem', marginRight: 5}}>
                            <img className="card-img-top" src="https://media.istockphoto.com/id/1008382300/vector/income-tax-filing-with-80c-deductions-illustration.jpg?s=612x612&w=0&k=20&c=tLQZl92ePpsldiL-dqJeFzF8XZqyrR_03wI-SrQ-jTs=" alt="Card image cap" style={{height: 262}}/>
                            <div className="card-body">
                                <h5 className="card-title"><strong> &#8377; {eightyCDeduction}</strong></h5>
                                <p className="card-text">By investing 80c deduction for 5 years-
                                    National Pension Scheme upto 60 years:{" "}</p>
                            </div>
                            <div className="card-footer">
                                <div>
                                    <button className="btn btn-success mt-5" style={{padding: 15, borderRadius: 12}} onClick={handleOpenCDeduction}>Explore</button>
                                    <Modal
                                        open={openCDeduction}
                                        onClose={handleCloseCDeduction}
                                        aria-labelledby="modal-modal-title"
                                        aria-describedby="modal-modal-description"
                                    >
                                        <Box sx={style}>
                                            <Typography id="modal-modal-title" variant="h6" component="h2">
                                                Section 80C Deductions List
                                            </Typography>
                                            <Typography id="modal-modal-description" sx={{mt: 2}}>
                                                <table className="table">
                                                    <thead className="thead-dark">
                                                    <tr>
                                                        <th scope="col">Investment options</th>
                                                        <th scope="col">Average Interest</th>
                                                        <th scope="col">Lock-in period for</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td>ELSS funds</td>
                                                        <td>12% – 15%</td>
                                                        <td>3 years</td>
                                                    </tr>
                                                    <tr>
                                                        <td>NPS Scheme</td>
                                                        <td>8% – 10%</td>
                                                        <td>Till 60 years of age</td>
                                                    </tr>
                                                    <tr>
                                                        <td>ULIP</td>
                                                        <td>8% – 10%</td>
                                                        <td>5 years</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Sukanya Samriddhi Yojana</td>
                                                        <td>8.50%</td>
                                                        <td>Till girl child reaches 21 years of age </td>
                                                    </tr>
                                                    <tr>
                                                        <td>National Savings Certificate</td>
                                                        <td>7.9%</td>
                                                        <td>5 years</td>
                                                    </tr>
                                                    <tr>
                                                        <td>PPF</td>
                                                        <td>7.90%</td>
                                                        <td>15 years</td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </Typography>
                                        </Box>
                                    </Modal>
                                </div>
                            </div>
                        </div>

                        <div className="card" style={{width: 18 + 'rem', marginRight: 5, marginTop: 5}}>
                            <img className="card-img-top" src="https://img.freepik.com/free-vector/married-couple-investing-savings-into-new-home-people-taking-credit-bank-money-buying-house-flat-vector-illustration-mortgage-ownership-property-concept-banner-landing-web-page_74855-25182.jpg" alt="Card image cap" style={{height: 262}}/>
                            <div className="card-body">
                                <h5 className="card-title"><strong> &#8377; {homeLoanDeduction}</strong></h5>
                                <p className="card-text">Home Loan Interest under Section 80EE Assuming loan amount is 10 lakhs,
                                    interest rate is 8% and tenure is 20 years:{" "}</p>
                            </div>
                            <div className="card-footer">
                                <div>
                                    <button className="btn btn-success mt-5" style={{padding: 15, borderRadius: 12}} onClick={handleOpenLoanDeduction}>Explore</button>
                                    <Modal
                                        open={openLoanDeduction}
                                        onClose={handleCloseLoanDeduction}
                                        aria-labelledby="modal-modal-title"
                                        aria-describedby="modal-modal-description"
                                    >
                                        <Box sx={style}>
                                            <Typography id="modal-modal-title" variant="h6" component="h2">
                                                Tax benefit on Home loan
                                            </Typography>
                                            <Typography id="modal-modal-description" sx={{mt: 2}}>
                                                <h6 className="card-title mb-2"><strong>Home Loan Tax Benefit</strong></h6>
                                                <p className="card-text">Whether you are a salaried or a self-employed individual, you are eligible to invest in a housing property as well as for the income tax deductions as stated under Section 80C. You can avail of a home loan tax benefit on both, principal repayment and the interest component of your EMI. Here’s how:</p>
                                                <p className="card-text">Section 80C:
                                                    Deductions under this section can help you with tax benefits of up to Rs. 1.5 lakhs on the principal amount.</p>
                                                <p className="card-text">Section 24:
                                                    Under this section you are allowed to enjoy tax benefits on the interest amount and up to Rs. 2 lakhs.</p>
                                                <p className="card-text">Section 80EE:
                                                    First-time home buyers can get an additional deduction of up to Rs. 50,000 on the interest component under Section 80EE.</p>
                                                <p className="card-text">Stamp Duty Waiver:
                                                    Women home buyers get a concession of 1 % on the stamp duty and registration costs. So, having a female co-applicant can help you with additional tax benefit.</p>
                                            </Typography>
                                        </Box>
                                    </Modal>
                                </div>
                            </div>
                        </div>

                        <div className="card" style={{width: 18 + 'rem', marginRight: 5, marginTop: 5}}>
                            <img className="card-img-top" src="https://img.freepik.com/free-vector/doctors-concept-illustration_114360-1515.jpg" alt="Card image cap" style={{height: 262}}/>
                            <div className="card-body">
                                <h5 className="card-title"><strong> &#8377; {medicalDeductionAmount}</strong></h5>
                                <p className="card-text">The deduction amount is calculated based on the limits specified in section 80DDB of the Income Tax Act,
                                    which depend on the age of the person and dependent and the amount of the medical expense.:{" "}</p>
                            </div>
                            <div className="card-footer">
                                <div>
                                    <button className="btn btn-success mt-5" style={{padding: 15, borderRadius: 12}} onClick={handleOpenDeductionAmount}>Explore</button>
                                    <Modal
                                        open={openDeductionAmount}
                                        onClose={handleCloseDeductionAmount}
                                        aria-labelledby="modal-modal-title"
                                        aria-describedby="modal-modal-description"
                                    >
                                        <Box sx={style}>
                                            <Typography id="modal-modal-title" variant="h6" component="h2">
                                                Eligibility to Claim Tax Deductions on Medical Insurance
                                            </Typography>
                                            <Typography id="modal-modal-description" sx={{mt: 2}}>
                                                <table className="table">
                                                    <thead className="thead-dark">
                                                    <tr>
                                                        <th scope="col">SCENARIO</th>
                                                        <th scope="col">TAX DEDUCTIONS UNDER SECTION 80D</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td>Self and Family (All below 60 years)</td>
                                                        <td>Rs. 25,000</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Self and Family + Parents (All below 60 years)</td>
                                                        <td>Rs. 25,000 + Rs. 25,000 = Rs. 50,000</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Self and Family (Below 60 years) + Senior Citizen Parents</td>
                                                        <td>Rs. 25,000 + Rs. 50,000 = Rs. 75,000</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Self and Family (Eldest is above 60 years) + Senior Citizen Parents</td>
                                                        <td>Rs. 50,000 + Rs. 50,000 = Rs. 1,00,000</td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </Typography>
                                        </Box>
                                    </Modal>
                                </div>
                            </div>
                        </div>

                        <div className="card" style={{width: 18 + 'rem', marginRight: 5, marginTop: 5}}>
                            <img className="card-img-top" src="https://cdn-scripbox-wordpress.scripbox.com/wp-content/uploads/2021/06/section-80gg-vector.png" alt="Card image cap" style={{height: 262}}/>
                            <div className="card-body">
                                <h5 className="card-title"><strong> &#8377; {deduction80GG}</strong></h5>
                                <p className="card-text">Tax Deduction under section 80GG of Income Tax Act:{" "}</p>
                            </div>
                            <div className="card-footer">
                                <div>
                                    <button className="btn btn-success mt-5" style={{padding: 15, borderRadius: 12}} onClick={handleOpen80GG}>Explore</button>
                                    <Modal
                                        open={open80GG}
                                        onClose={handleClose80GG}
                                        aria-labelledby="modal-modal-title"
                                        aria-describedby="modal-modal-description"
                                    >
                                        <Box sx={style}>
                                            <Typography id="modal-modal-title" variant="h6" component="h2">
                                                Deductions Under Section 80GG
                                            </Typography>
                                            <Typography id="modal-modal-description" sx={{mt: 2}}>
                                                <p className="card-text">Tax deductions under this section are based on Tax Rule 2A. As per Section 10(13A), the least amount from the following calculations is considered a non-taxable income. </p>
                                                <p className="card-text"><li>Rs.5000 per month or Rs.60000 a year.</li>
                                                <li>The yearly rent amount minus 10% of the taxpayer’s adjusted total income.</li>
                                                <li>25% of the adjusted total income for a year.</li>
                                                </p>
                                                <p className="card-text">clause where 25% of the ATI is considered as tax discount is applicable in the first case, since the quantum in this calculation is lower than the other two clauses. However, in Individual B’s case, yearly rent minus 10% of ATI gives a lower quantum than the other calculations.
                                                    Thus, it is the applicable tax deduction for Individual B.</p>
                                                <p className="card-text">The property or properties they own should not be in the same city or location as their workplace. If they own a property within the city but decide to live in a rented apartment, Section 80GG does not apply to their yearly income taxes. </p>
                                            </Typography>
                                        </Box>
                                    </Modal>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}

export default TaxSavingOptions