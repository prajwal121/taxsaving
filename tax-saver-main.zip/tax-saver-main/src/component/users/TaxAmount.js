import Card from "../UI/Card";
import React from 'react'

function TaxAmount(props){

    return (
        <div>
            <div className="container mb-3 align-middle">
                <div className="row text-center p-5">
                    <div className="col-md-8 ">
                        <Card>
                            <div className="card-body p-3">
                                <h3>Your Taxable Amount:</h3>
                                <p className="card-text">&#8377; {props.taxAmount}</p>
                            </div>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default TaxAmount;