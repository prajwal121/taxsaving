import React, {useState} from 'react';
import {
    FormControl,
    Grid,
    InputAdornment,
    InputLabel,
    OutlinedInput,
    TextField,
    Typography,
} from "@mui/material";
import Button from '@mui/material/Button';
import TaxAmount from "./TaxAmount";
import TaxSavingOptions from "./TaxSavingOptions";
import './UserDetails.module.css'
import axios from 'axios'
import ReceiptIcon from '@mui/icons-material/Receipt';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import CircularProgress from '@mui/material/CircularProgress';
import Header from "../UI/Header";


function calculateTaxLiability(income, deductions, otherInvestments) {
    const Income = income * 12
    const taxableIncome = Income - deductions - otherInvestments;
    let tax = 0;
    if (taxableIncome <= 250000) {
        tax = 0;
    } else if (taxableIncome > 250000 && taxableIncome <= 500000) {
        tax = (taxableIncome - 250000) * 0.05;
    } else if (taxableIncome > 500000 && taxableIncome <= 750000) {
        tax = 12500 + (taxableIncome - 500000) * 0.1;
    } else if (taxableIncome > 750000 && taxableIncome <= 1000000) {
        tax = 37500 + (taxableIncome - 750000) * 0.15;
    } else if (taxableIncome > 1000000 && taxableIncome <= 1250000) {
        tax = 75000 + (taxableIncome - 1000000) * 0.2;
    } else if (taxableIncome > 1250000 && taxableIncome <= 1500000) {
        tax = 125000 + (taxableIncome - 1250000) * 0.25;
    } else {
        tax = 187500 + (taxableIncome - 1500000) * 0.3;
    }


    return tax;
}


function UsersDetails(props) {

    const [name, setName] = useState('');
    const [age, setAge] = useState(0);
    const [dependentAge, setDependentAge] = useState(0);
    const [income, setIncome] = useState(0);
    const [deductions, setDeductions] = useState(0);
    const [medicalInvestments, setMedicalInvestment] = useState(0);
    // passing tax-liability using props (properties)
    const [taxLiability, setTaxLiability] = useState(0);
    const [showComponent, setShowComponent] = useState(false);
    const [showForm, setShowForm] = useState(true);
    const [savedIncome, setSavedIncome] = useState({});

    const handleNameChange = event => {
        setName(event.target.value);
    }

    const handleAgeChange = event => {
        setAge(event.target.value);
    }
    const handleIncomeChange = event => {
        setIncome(event.target.value);
    };

    const handleDeductionsChange = event => {
        setDeductions(event.target.value);
    };

    const handleInvestmentsChange = event => {
        setMedicalInvestment(event.target.value)
    }

    const handleDependentAgeChange = event => {
        setDependentAge(event.target.value)
    }

    const handleSubmit = async event => {
        event.preventDefault();
        const tax = calculateTaxLiability(income, deductions, medicalInvestments);
        setTaxLiability(tax);

        // Save details
        await saveIncome(tax)

        setShowComponent(true);
        setShowForm(!showForm);
        console.log(taxLiability)
    }

    const saveIncome = async (tax) => {
        axios.post(`${process.env.REACT_APP_API_ENDPOINT}/income/add`,
            {
                name,
                age,
                gross_income: income,
                deductions,
                investments: medicalInvestments,
                tax
            })
            .then(res => {
                setSavedIncome(res.data)
            })
            .catch(err => {
                console.log(err)
            })
    }

    /** OCR **/
    const [ocrProcess, setOcrProcess] = useState(false)
    const handleFileChange = (e) => {
        setOcrProcess(true)
        let formData = new FormData();
        formData.append("file", e.target.files[0]);
        axios.post(`${process.env.REACT_APP_API_ENDPOINT}/salarySlip`, formData)
            .then(res => {
                console.log(res.data)
                setIncome(Number(res.data.gross_income))
                setDeductions(Number(res.data.total_deductions))
            })
            .catch(err => {
                console.log(err)
            })
            .finally(() => {
                setOcrProcess(false)
            })
    }

    return (
            <div>
                <Header/>
                {showForm && (<div className="container mb-2">
                    <div className="row col-md-6">
                        <Typography variant="h6" gutterBottom>
                            Please fill all details
                        </Typography>
                    </div>
                </div>)}
                <form onSubmit={handleSubmit}>
                    {showForm && (<div className="container col-md-12">
                        <div className="mb-3">
                            <Grid container spacing={2}>
                                <Grid item xs={6} md={4}>
                                    <TextField fullWidth
                                               id="name"
                                               label="Name"
                                               variant="outlined"
                                               value={name}
                                               onChange={handleNameChange} />
                                </Grid>
                                <Grid item xs={6} md={4}>
                                    <TextField fullWidth
                                               id="age"
                                               label="Age"
                                               variant="outlined"
                                               type="number"
                                               value={age}
                                               required
                                               onChange={handleAgeChange} />
                                    <div className="invalid-feedback">
                                        Please provide Age
                                    </div>
                                </Grid>
                            </Grid>
                        </div>
                        <div className="mb-3">
                            <Grid container spacing={2}>
                                <Grid item xs={6} md={4}>
                                    <FormControl fullWidth>
                                        <InputLabel htmlFor="grs-income">Gross Income (monthly)</InputLabel>
                                        <OutlinedInput
                                            id="grs-income"
                                            startAdornment={<InputAdornment position="start">&#8377;</InputAdornment>}
                                            label="Gross Income (monthly)"
                                            variant="outlined"
                                            type="number"
                                            value={income}
                                            onChange={handleIncomeChange}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={6} md={4}>
                                    <FormControl fullWidth>
                                        <InputLabel htmlFor="deduction">Deduction</InputLabel>
                                        <OutlinedInput
                                            id="deduction"
                                            startAdornment={<InputAdornment position="start">&#8377;</InputAdornment>}
                                            label="Deduction"
                                            variant="outlined"
                                            type="number"
                                            value={deductions}
                                            onChange={handleDeductionsChange}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                        </div>
                        <div className="mb-3">
                            <Grid container spacing={2}>
                                <Grid item xs={6} md={4}>
                                    <FormControl fullWidth>
                                        <InputLabel htmlFor="deduction">Dependent Age</InputLabel>
                                        <OutlinedInput
                                            id="dependent-age"
                                            label="Dependent Age"
                                            variant="outlined"
                                            type="number"
                                            value={dependentAge}
                                            required
                                            onChange={handleDependentAgeChange}
                                        />
                                        <div className="invalid-feedback">
                                            Please provide Dependent Age
                                        </div>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={6} md={4}>
                                    <FormControl fullWidth>
                                        <InputLabel htmlFor="deduction">Medical Expenses</InputLabel>
                                        <OutlinedInput
                                            id="medical-investments"
                                            startAdornment={<InputAdornment position="start">&#8377;</InputAdornment>}
                                            label="Medical Expenses"
                                            variant="outlined"
                                            type="number"
                                            value={medicalInvestments}
                                            onChange={handleInvestmentsChange}
                                        />
                                        <div className="invalid-feedback">
                                            Please provide Medical Expenses
                                        </div>
                                    </FormControl>
                                </Grid>
                            </Grid>
                        </div>
                    </div>)}

                    {showForm && (
                        <div className="container align-middle">
                            <div className="text-center">
                                <Button variant="outlined" component="label" endIcon={(ocrProcess)?<CircularProgress color="success" />:<ReceiptIcon />}>
                                    Load From Salary Slip
                                    <input hidden accept="image/png, image/jpg, image/jpeg" type="file" onChange={handleFileChange} />
                                </Button>
                            </div>
                            <hr />
                        </div>
                    ) }
                    <div>
                        {showComponent &&  (
                                <div className="container align-middle">
                                    <TaxAmount taxAmount = {taxLiability}/>
                                </div>
                            )}
                        {showComponent && (
                                <div className="container">
                                  <TaxSavingOptions
                                      totalTaxtAmount = {taxLiability}
                                      savedIncome={savedIncome}
                                      age ={age}
                                      dependentAge = {dependentAge}
                                      medicalInvestments = {medicalInvestments}
                                  />
                                </div>
                            )
                        }
                        {showForm && (
                            <div className='row d-flex justify-content-center'>
                                <div className= 'col-md-2'>
                                    <Button type="submit" variant="contained" color="success" endIcon={<NavigateNextIcon />}>Next</Button>
                                </div>
                            </div>
                        )}
                    </div>
                </form>
            </div>
    )
}

export default UsersDetails
