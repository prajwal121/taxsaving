const mongoose = require('mongoose')

const Schema = mongoose.Schema

const incomeSchema = new Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    age: {
        type: Number,
        required: true,
        trim: true
    },
    gross_income: {
        type: Number,
        required: true,
        trim: true
    },
    deductions: {
        type: Number,
        required: true,
        trim: true
    },
    investments: {
        type: Number,
        required: true,
        trim: true
    },
    tax: {
        type: Number,
        required: true,
        trim: true
    }
}, {
    collation: 'tax-saver',
    timestamps: true
})

const Income = mongoose.model('Income', incomeSchema)

module.exports = Income