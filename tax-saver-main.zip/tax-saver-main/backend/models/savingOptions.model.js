const mongoose = require('mongoose')

const Schema = mongoose.Schema

const savingOptionsSchema = new Schema({
    income_id: {
        type: String,
        required: true,
        trim: true
    },
    RetirementSavings: {
        type: Number,
        trim: true
    },
    DeductionsSavings: {
        type: Number,
        trim: true
    },
    InvestmentSavings: {
        type: Number,
        trim: true
    },
    EightyCDeduction: {
        type: Number,
        trim: true
    },
}, {
    collation: 'tax-saver',
    timestamps: true
})

const savingOptions = mongoose.model('SavingOptions', savingOptionsSchema)

module.exports = savingOptions