const express = require('express')
const cors = require('cors')
const mongoose = require('mongoose')

require('dotenv').config()

const api = express()
const port = process.env.PORT || 5000

api.use(cors())
api.use(express.json())

// Database connection
const dbUri = process.env.MONGODB_URI || 'mongodb+srv://<username>:<password>@app-name.m5f2jfq.mongodb.net/?retryWrites=true&w=majority'
mongoose.connect(dbUri)
const dbConnection = mongoose.connection
dbConnection.once('open', ()=>{
    console.log('MongoDB connection established! ✅ ')
    console.log('API is now operational 🌍 ')
})

/** Routes */
api.get('/', (req, res) => {
    res.send('Tax Saver API')
})
api.use('/income', require('./routes/income'))
api.use('/saving_options', require('./routes/savingOptions'))
api.use('/salarySlip', require('./routes/salarySlipReader'))

/** End of Routes */

api.listen(port, ()=>{
    console.log(`API is up and running on port ${port} 🚀 `)
})
