const router = require('express').Router()
const multer = require('multer');
const Tesseract = require("tesseract.js")
const fs= require('fs')

let upload = multer({ dest: 'uploads/' })

const parseSalaryData = async (string) => {

    let gross_income = 0
    let total_deductions = 0

    let dataArray = string.split('\n')
    dataArray.forEach((item) => {
        //Gross income
        if (
            item.includes('Total Earnings')
        )
        {
            gross_income = item.split("Total Earnings").pop() // remove Total Earnings string
            gross_income = gross_income.replace(/[a-z]/gi,'') // remove all alphabets
            gross_income = gross_income.trim() // trim
            gross_income = (gross_income.indexOf(' ') >= 0) ? gross_income.substring(0, gross_income.indexOf(' ')) : gross_income // get the number before first space

        }
        if (
            item.includes('Gross Salary')
        )
        {
            gross_income = item.split("Gross Salary").pop() // remove Total Earnings string
            gross_income = gross_income.replace(/[a-z]/gi,'') // remove all alphabets
            gross_income = gross_income.trim() // trim
            gross_income = (gross_income.indexOf(' ') >= 0) ? gross_income.substring(0, gross_income.indexOf(' ')) : gross_income // get the number before first space

        }


        if (
            item.includes('Total Deductions')
        )
        {
            total_deductions = item.split("Total Deductions").pop() // remove Total Deductions string
            total_deductions = total_deductions.replace(/[a-z]/gi,'') // remove all alphabets
            total_deductions = total_deductions.trim() // trim
            total_deductions = (total_deductions.indexOf(' ') >= 0) ? total_deductions.substring(0, total_deductions.indexOf(' ')) : total_deductions // get the number before first space

        }
    })

    return {
        gross_income,
        total_deductions,
        raw: string
    }
}

router.route('/').post(upload.single('file'), async (req, res) => {
    if (!req.file || Object.keys(req.file).length === 0) {
        return res.status(400).send('No files were uploaded.');
    }

    try {
        let image = fs.readFileSync(__dirname + '/../'+req.file.path,
            {
                encoding:null
            });
        const {data} = await Tesseract.recognize(image, "eng", {
        })
        res.json(await parseSalaryData(data.text))
    } catch (error) {
        res.status(400).send(error)
    }
})

module.exports = router