const router = require('express').Router()
let SavingOptions = require('../models/savingOptions.model')

router.route('/').get((req, res) => {
    SavingOptions.find()
        .then(savingOptionsData => res.json(savingOptionsData))
        .catch(err => res.status(400).json('Error:'+ err))
})

router.route('/add').post((req, res) => {
    const newSavingOptions = new SavingOptions(req.body)

    newSavingOptions.save()
        .then((savingOptions) => {
            res.json(savingOptions)
        })
        .catch(err => res.status(400).json('Error: '+ err))
})

module.exports = router