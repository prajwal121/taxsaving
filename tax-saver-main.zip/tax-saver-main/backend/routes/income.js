const router = require('express').Router()
let Income = require('../models/income.model')

router.route('/').get((req, res) => {
    Income.find()
        .then(incomeData => res.json(incomeData))
        .catch(err => res.status(400).json('Error:'+ err))
})

router.route('/add').post((req, res) => {
    const newIncome = new Income(req.body)

    newIncome.save()
        .then((income) => {
            res.json(income)
        })
        .catch(err => res.status(400).json('Error: '+ err))
})

module.exports = router